package Exceptions;

public class CacheAlreadyAddedException extends Exception {
  public CacheAlreadyAddedException () { super(); }
  public CacheAlreadyAddedException (String s) { super(s); }
}
