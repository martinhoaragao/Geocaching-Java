package Exceptions;


public class NoStatsException extends Exception {
  public NoStatsException () { super(); }
  public NoStatsException (String s) { super(s); }
}