package Exceptions;

public class NotAddedActivityYearIncorrectException extends Exception{

    public NotAddedActivityYearIncorrectException(){
        super();
    }

    public NotAddedActivityYearIncorrectException(String msg){
        super(msg);
    }
    
}
