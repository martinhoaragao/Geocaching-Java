package Exceptions;

public class PuzzleStarEx extends Exception{

    public PuzzleStarEx(){
        super();
    }

    public PuzzleStarEx(String msg){
        super(msg);
    }
    
}