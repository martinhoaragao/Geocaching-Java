package Exceptions;



public class IdAlreadyAssignedException extends Exception {
  public IdAlreadyAssignedException () { super(); }
  public IdAlreadyAssignedException (String s) { super(s); }
}